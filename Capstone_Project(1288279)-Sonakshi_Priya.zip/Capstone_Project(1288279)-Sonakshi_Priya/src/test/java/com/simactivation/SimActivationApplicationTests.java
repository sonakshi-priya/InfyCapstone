package com.simactivation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimActivationApplicationTests {

	@Test
	void contextLoads() {
	}

}
